#importing required libraries

from flask import Flask, request, render_template
import pandas as pd
import numpy as np
import re
import time
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from flask import Flask, render_template, request
import joblib
import numpy as np
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

app = Flask(__name__)


# Load the pre-trained model
model = joblib.load('Accident.pkl')
@app.route('/')
def home():
    return render_template('index.html')
    # User is not loggedin redirect to login page

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('predict.html')

@app.route('/category')
def category():
    return render_template('category.html')



@app.route("/predict", methods=["GET", "POST"])
def predict():
    if request.method == 'POST':
        # Get form data
        data = request.form.to_dict()
        
        # Map input data to the correct order of features
        features = [
            data['Age_band_of_driver'],
            data['Driving_experience'],
            data['Type_of_vehicle'],
            data['Area_accident_occured'],
            data['Lanes_or_Medians'],
            data['Road_allignment'],
            data['Types_of_Junction'],
            data['Road_surface_conditions'],
            data['Light_conditions'],
            data['Weather_conditions'],
            data['Type_of_collision'],
            data['Number_of_vehicles_involved'],
            data['Number_of_casualties'],
            data['Vehicle_movement'],
            data['Casualty_class'],
            data['Age_band_of_casualty'],
            data['Pedestrian_movement'],
            data['Cause_of_accident']
        ]
        
        # Convert features to numpy array
        features = np.array(features).reshape(1, -1)
        
        # Predict using the loaded model
        prediction = model.predict(features)[0]
        
        # Map prediction to actual label
        severity_mapping = {0: 'Fatal injury', 1: 'Serious Injury', 2: 'Slight Injury'}
        predict = severity_mapping[prediction]
        
        return render_template('predict.html', predict=predict)


if __name__ == "__main__":
    app.run(debug=True)